
<?php
    $localhost = "srv1412.hstgr.io";
    $username = "u499793037_attendance";
    $password = "XF:VY7+zD";
    $database = "u499793037_attendance";


    mysqli_connect($localhost, $username, $password, $database) or die("Connection Failed");
    $conn = mysqli_connect($localhost, $username, $password, $database);
  ?>
