<?php
    include 'layout/header.php';
    include 'layout/navigation.php';
    include 'layout/connection.php';
?>

<?php
if (isset($_GET['student_id'])) {
    $request_id = intval($_GET['student_id']);
    // Fetch and process the request based on $request_id
}
?>



<main id="main" class="main">

  <div class="pagetitle">
    <h1>Schedule Form</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.html">Schedule</a></li>
        <li class="breadcrumb-item active">Form</li>
      </ol>
    </nav>
  </div><!-- End Page Title -->

  <section class="section">
    <div class="row">
      <!-- Form Column -->
      <div class="col-lg-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Schedule Profile Identification</h5>



                                <?php
                    $userData = null;
                    if ($request_id) {

                        $stmt = $conn->prepare("SELECT firstname, lastname, role, username FROM user WHERE id_number = ?");
                        $stmt->bind_param("i", $request_id);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        $userData = $result->fetch_assoc();
                        $stmt->close();
                        $conn->close();
                    }
                    ?>

                          <form id="scheduleForm">
                            <input type="hidden" name="student_id" value="<?= htmlspecialchars($student_id); ?>">

                            <?php if ($userData): ?>
                              <div class="mb-3">
                                <label class="form-label">Student Name</label>
                                <input type="text" class="form-control" value="<?= htmlspecialchars($userData['firstname'] . ' ' . $userData['lastname']); ?>" disabled>
                              </div>
                              <div class="mb-3">
                                <label class="form-label">Username</label>
                                <input type="text" class="form-control" value="<?= htmlspecialchars($userData['username']); ?>" disabled>
                              </div>
                              <div class="mb-3">
                                <label class="form-label">Role</label>
                                <input type="text" class="form-control" value="<?= htmlspecialchars($userData['role']); ?>" disabled>
                              </div>
                            <?php else: ?>
                              <div class="alert alert-warning">⚠️ No user found for ID <?= htmlspecialchars($student_id); ?></div>
                            <?php endif; ?>
                            <div class="d-grid">
                              <button id="openCameraBtn" class="btn btn-primary">Open Camera</button>
                            </div>
                          </form>
          </div>
        </div>
      </div>

      <!-- Table Column -->
      <div class="col-lg-8">
        <div class="card">
          <div class="card-body">
                              <h5 class="card-title">Camera Preview</h5>
                      <div id="cameraResult"></div>
                      <video id="video" autoplay playsinline width="100%" style="max-height:300px;"></video>
                      <button id="snapBtn" class="btn btn-success mt-2">Capture & Recognize</button>
                      <canvas id="canvas" style="display:none;"></canvas>

          </div>
        </div>
      </div>
    </div>
  </section>

</main><!-- End #main -->
<?php
include 'layout/footer.php';
?>
<script>
// Load table on page loa

document.addEventListener('DOMContentLoaded', () => {
  const openCameraBtn = document.getElementById('openCameraBtn');
  const video = document.getElementById('video');
  const canvas = document.getElementById('canvas');
  const snapBtn = document.getElementById('snapBtn');
  const cameraResult = document.getElementById('cameraResult');

  let streamStarted = false;

  openCameraBtn.addEventListener('click', () => {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => {
          video.srcObject = stream;
          streamStarted = true;
        })
        .catch(err => {
          cameraResult.innerHTML = `<div class="alert alert-danger">🚫 Camera access denied.</div>`;
        });
    } else {
      cameraResult.innerHTML = `<div class="alert alert-warning">⚠️ Camera not supported in this browser.</div>`;
    }
  });

  snapBtn.addEventListener('click', () => {
    if (!streamStarted) return;

    const ctx = canvas.getContext('2d');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob(blob => {
      const formData = new FormData();
      formData.append('image', blob, 'camera.jpg');
      formData.append('recognize', '1');

      fetch('recognize.php', { method: 'POST', body: formData })
        .then(response => response.text())
        .then(html => {
          cameraResult.innerHTML = html;
        })
        .catch(err => {
          cameraResult.innerHTML = `<div class="alert alert-danger">❌ Recognition failed.</div>`;
        });
    }, 'image/jpeg', 0.95);
  });
});




document.getElementById("scheduleForm").addEventListener("submit", function(e) {
  e.preventDefault();

  const formData = new FormData(this);

  fetch("ajax/insert_schedule.php", {
    method: "POST",
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      alert("Schedule submitted successfully!");
      document.getElementById("scheduleForm").reset();
      location.reload();
    } else {
      alert("Submission failed: " + data.message);
    }
  })
  .catch(error => {
    console.error("Error:", error);
    alert("An error occurred while submitting.");
  });
});





</script>