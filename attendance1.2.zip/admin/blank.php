<?php
include 'layout/header.php';
?>


<body>
<?php
    include 'layout/navigation.php';
?>




<?php
include 'layout/footer.php';
?>